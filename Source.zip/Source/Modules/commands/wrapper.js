const { default: axios } = require('axios');
const clc = require('cli-color');
const fs = require('fs');
const path = require('path');
const rimraf = require('rimraf')
// global.endpoint = 'https://woidzero.xyz/webapi/hpm/find.php?name=';
async function get_mod(mod_name, name, version) {
    try {
        const css = await axios.get(`https://cdnjs.cloudflare.com/ajax/libs/${mod_name}/${version}/css/${name}.min.css`);
        const js = await axios.get(`https://cdnjs.cloudflare.com/ajax/libs/${mod_name}/${version}/js/${name}.min.js`);
        console.log(clc.bgGreen(clc.black(`\n==> [hpm@Success]: Sucessfully fetched "${mod_name}" package.`)));
        return {
            css: css.data,
            js: js.data
        };
    } catch (e) {
        console.log(clc.bgRed(clc.black('\n[hpm@FetchError]: Something went wrong with fetching data on the server. Please try again.')));
    }
};


class commands {
    constructor() {
        return this;
    }

    async install(mod_name, name, version) {
        const response = await get_mod(mod_name, name, version);
        try {
            fs.mkdirSync(path.resolve(process.cwd(), 'modules'));
            fs.mkdirSync(path.resolve(process.cwd(), 'modules', mod_name));
            fs.writeFileSync(path.resolve(process.cwd(), 'modules', mod_name, `${name}.min.js`), response.js);
            fs.writeFileSync(path.resolve(process.cwd(), 'modules', mod_name, `${name}.min.css`), response.css);
            console.log(clc.bold(clc.greenBright(`\n==> Successfully installed "${mod_name}^${version}".`)));
            return response;
        } catch (e) {
            rimraf.sync(path.resolve(process.cwd(), 'modules'));
            fs.mkdirSync(path.resolve(process.cwd(), 'modules'));
            fs.mkdirSync(path.resolve(process.cwd(), 'modules', mod_name));
            fs.writeFileSync(path.resolve(process.cwd(), 'modules', mod_name, `${name}.min.js`), response.js);
            fs.writeFileSync(path.resolve(process.cwd(), 'modules', mod_name, `${name}.min.css`), response.css);
            console.log(clc.underline(clc.yellowBright('[hpm@WarnMessage]:'), clc.yellowBright(e.message) + clc.yellowBright('.')));
        }
    }

    uninstall(mod_name) {
        if (Boolean(fs.readdirSync((path.resolve(process.cwd(), 'modules', mod_name))))) {
            rimraf.sync(path.resolve(process.cwd(), 'modules', mod_name), { rmdirSync: false });
            console.log(clc.bold(clc.greenBright(`==> Sucessfully uninstalled "${mod_name}" package.`)));
        } else {
            console.log(clc.bold(clc.redBright(`[hpm@ErrorMessage]: Undefined "${mod_name}" package.`)));
        }
    }

    reinstall(mod_name, name, version) {
        this.uninstall(mod_name);
        this.install(mod_name, name, version);
    }
}

exports._commands = commands;